function appController(periodService, $scope, currentUser, mechanismsService,
                       approvalLevelsService, $q, toastr, AppManifest,
                       systemSettings, $translate, d2Api,
                       organisationunitsService) {
    var self = this;

    this.loading = true;
    this.actionItems = 0;
    this.state = {};
    this.showData = false;
    this.tabs = {
        accept: {
            access: false,
            name: 'Accept',
            state: false,
            action: []
        },
        submit: {
            access: false,
            name: 'Submit',
            state: false,
            action: []
        },
        unsubmit: {
            access: false,
            name: 'Unsubmit',
            state: false,
            action: []
        },
        view: {
            access: true,
            name: 'View',
            state: false,
            action: ['view']
        }
    };

    this.currentUser = {};
    this.text = {};

    this.headerBar = {
        logo: AppManifest.activities.dhis.href + '/dhis-web-commons/css/light_blue/logo_banner.png',
        title: systemSettings.applicationTitle,
        link: AppManifest.activities.dhis.href
    };

    this.hasTableDetails = function () {
        if (mechanismsService.categories.length > 0 &&
            mechanismsService.dataSetIds.length > 0 &&
            mechanismsService.organisationUnit && mechanismsService.organisationUnit !== '' &&
            angular.isString(mechanismsService.period)) {
            return true;
        }
        return false;
    };

    this.getTableData = function () {
        if (self.hasTableDetails()) {
            $translate('Loading...').then(function (translation) {
                self.status = translation;
            });

            self.loading = true;

            $q.all([userApprovalLevelPromise, approvalLevelsService.get()]).then(function (data) {
                mechanismsService.getMechanisms().then(function (mechanisms) {
                    var currentUserApprovalLevel = data[0][0];

                    self.actionItems = 0;
                    _.each(mechanisms, function (mechanism) {
                        if (mechanism.mayApprove && (mechanism.level === currentUserApprovalLevel.level)) {
                            self.actionItems += 1;
                        }

                        if (mechanism.mayAccept && (mechanism.level === (currentUserApprovalLevel.level - 1))) {
                            self.actionItems += 1;
                        }
                    });

                    self.setStatus();

                    $scope.$broadcast('MECHANISMS.updated', mechanisms);
                    self.loading = false;
                });
            });
        }
    };

    this.setStatus = function () {
        if (this.actionItems === 0) {
            $translate('No actions required').then(function (translations) {
                self.status = translations;
            });
        } else {
            $translate(this.actionItems > 1 ? 'mechanisms require action' : 'mechanism requires action').then(function (translation) {
                self.status = ' ' + translation;
            });
        }
    };

    this.getStatus = function () {
        if (this.status) {
            return this.status;
        }
    }

    this.hasAllDetails = function () {
        if ($scope.details.period
            && ($scope.details.currentSelection.length > 0
            && $scope.details.dataSets
            && $scope.details.orgUnit
            && this.getActiveTab())) {
            return true;
        }
        return false;
    };

    this.updateDataView = function () {
        function generateActions() {
            var actions = {
                approve: [],
                unapprove: [],
                accept: [],
                unaccept: []
            };
            _.each($scope.details.currentSelection, function (mechanism) {
                if (mechanism.mayApprove === true) { actions.approve.push(mechanism.id) }
                if (mechanism.mayUnapprove === true) { actions.unapprove.push(mechanism.id) }
                if (mechanism.mayAccept === true) { actions.accept.push(mechanism.id) }
                if (mechanism.mayUnaccept === true) { actions.unaccept.push(mechanism.id) }
            });

            return actions;
        }
        if (this.getActiveTab().name === 'View') {
            $scope.details.actions = {};
        } else {
            $scope.details.actions = generateActions();
        }

        if (this.hasAllDetails()) {
            $scope.$broadcast('DATAVIEW.update', $scope.details);
            this.showData = true;
        }
    };

    this.setActive = function (tabName, isActive) {
        var active = _.filter(this.state, function (item) {
            if (item === true ) {
                return true;
            }
            return false;
        });

        if (active.length === 0) {
            _.each(this.state, function (item) {
                if (item !== tabName) {
                    item = false;
                }
            });
            this.state[tabName] = isActive;
        }
    };

    this.getActiveTab = function () {
        return _.find(this.tabs, { state: true } );
    };

    this.deSelect = function () {
        $scope.details.currentSelection = [];
        this.updateViewButton();
        $scope.$broadcast('RECORDTABLE.selection.clear');
    };

    $scope.approvalLevel = {};

    $translate(['View/Act on', 'mechanism(s)']).then(function (translations) {
        self.text.viewAct = [translations['View/Act on'], 0, translations['mechanism(s)']].join(' ');
    });

    currentUser.permissions.then(function (permissions) {
        permissions = _(permissions);

        if (permissions.contains('ALL')) {
            self.tabs.accept.access = true;
            self.tabs.accept.name = 'Accept/Return';
            self.tabs.accept.action = ['accept', 'unapprove'];
            self.tabs.submit.access = true;
            self.tabs.submit.name = 'Submit/Unaccept';
            self.tabs.submit.action = ['approve', 'unaccept'];
            self.tabs.unsubmit.access = true;
            self.tabs.unsubmit.name = 'Unsubmit';
            self.tabs.unsubmit.action = ['unapprove'];
            return;
        }

        if (permissions.contains('F_ACCEPT_DATA_LOWER_LEVELS')) {
            if ((permissions.contains('F_APPROVE_DATA') || permissions.contains('F_APPROVE_DATA_LOWER_LEVELS'))) {
                //All permissions
                self.tabs.accept.access = true;
                self.tabs.accept.name = 'Accept/Return';
                self.tabs.accept.action = ['accept', 'unapprove'];
                self.tabs.submit.access = true;
                self.tabs.submit.name = 'Submit/Unaccept';
                self.tabs.submit.action = ['approve', 'unaccept'];
                self.tabs.unsubmit.access = true;
                self.tabs.unsubmit.name = 'Unsubmit';
                self.tabs.unsubmit.action = ['unapprove'];
            } else {
                //Only accept lower levels
                self.tabs.accept.access = true;
                self.tabs.accept.name = 'Accept/Return';
                self.tabs.accept.action = ['accept', 'unapprove'];
                self.tabs.submit.access = true;
                self.tabs.submit.name = 'Unaccept';
                self.tabs.submit.action = ['unaccept'];
            }
        } else {
            if ((permissions.contains('F_APPROVE_DATA') || permissions.contains('F_APPROVE_DATA_LOWER_LEVELS'))) {
                //Only approve
                self.tabs.submit.access = true;
                self.tabs.submit.name = 'Submit';
                self.tabs.submit.action = ['approve'];
                self.tabs.unsubmit.access = true;
                self.tabs.unsubmit.name = 'Unsubmit';
                self.tabs.unsubmit.action = ['unapprove'];
            } else {
                //Only view
            }
        }
    });

    $scope.details = {
        orgUnit: undefined,
        period: undefined,
        dataSets: undefined,
        currentSelection: []
    };

    this.updateTitle = function () {
        var title = [];

        if ($scope.approvalLevel && $scope.approvalLevel.categoryOptionGroupSet && $scope.approvalLevel.categoryOptionGroupSet.name) {
            title.push($scope.approvalLevel.categoryOptionGroupSet.name);
        }

        if (self.currentUser.orgUnit && self.currentUser.orgUnit.name) {
            title.push(self.currentUser.orgUnit.name);
        }

        title.push($translate.instant('Data approval'));

        self.title = title.join(' - ');
    }

    this.updateViewButton = function () {
        this.text.viewAct = [$translate.instant('View/Act on'),
            $scope.details.currentSelection.length,
            $translate.instant('mechanism(s)')].join(' ');
    }

    //Get the users org unit off the user
    currentUser.then(function () {
        var orgUnit;

        if (currentUser.valueFor('dataViewOrganisationUnits') &&
            currentUser.valueFor('dataViewOrganisationUnits')[0]) {
            orgUnit = currentUser.valueFor('dataViewOrganisationUnits')[0];
        } else {
            orgUnit = currentUser.valueFor('organisationUnits')[0];
        }

        $scope.details.orgUnit = orgUnit.id;
        self.currentUser.orgUnit = orgUnit;

        organisationunitsService.currentOrganisationUnit = orgUnit;

        self.updateTitle();
    });

    d2Api.addEndPoint('me/dataApprovalLevels', true);
    var userApprovalLevelPromise = d2Api.getEndPoint('me/dataApprovalLevels').get();
    userApprovalLevelPromise.then(function (approvalLevel) {
        $scope.approvalLevel = $scope.details.approvalLevel = approvalLevel[0];
        if ($scope.approvalLevel.categoryOptionGroupSet) {
            self.updateTitle();
        }
        organisationunitsService.currentOrganisationUnit.level = $scope.approvalLevel.level;
    });

    $q.all([userApprovalLevelPromise, approvalLevelsService.get()]).then(function (result) {
        if ($scope.approvalLevel.level === result[1].length) {
            self.tabs.accept.access = false;
            self.tabs.accept.state = false;
            self.tabs.submit.access = true;
            self.tabs.submit.state = true;
            self.tabs.submit.name = 'Pending';
        }
    });

    //When the dataset group is changed update the filter types and the datasets
    $scope.$on('DATASETGROUP.changed', function (event, dataSets) {
        function equalArrays(left, right) {
            var result = true;

            if (left.length !== right.length) {
                return false;
            }

            left.forEach(function (item, index) {
                result = (item === right[index]) && true;
            });
            return result;
        }

        function differentPeriodSets(periodsLeft, periodsRight) {
            return !equalArrays(periodsLeft, periodsRight);
        }

        if (differentPeriodSets(periodService.getPeriodTypesForDataSet(dataSets.getPeriodTypes()), periodService.getPeriodTypes())) {
            periodService.filterPeriodTypes(dataSets.getPeriodTypes());
        }

        $scope.details.dataSets = dataSets.get();
        mechanismsService.categories = dataSets.getCategoryIds();
        mechanismsService.dataSetIds = dataSets.getIds();
        mechanismsService.dataSets = dataSets.get();
        mechanismsService.organisationUnit = organisationunitsService.currentOrganisationUnit.id;

        $scope.details.currentSelection = [];

        //TODO: Since it's pepfar we might not have to request the mechanism again when the
        //category changes, as they only use one category
        if (self.hasTableDetails()) {
            self.showData = false;
            self.getTableData();
            self.deSelect();
        }

        self.updateViewButton();
    });

    $scope.$on('RECORDTABLE.selection.changed', function (event, selection) {
        $scope.details.currentSelection = selection;

        self.updateViewButton();
    });

    $scope.$on('APP.submit.success', function (event, mechanisms) {
        var successMessage = [mechanisms.action[0].toUpperCase(),
                              mechanisms.action.substr(1),
                              ' successful for ',
                              mechanisms.mechanisms.length,
                              ' mechanism(s)'];
        if (mechanisms.mechanisms.length < 10) {
            //FIXME: Html in controller :( Bad practice
            successMessage.push('<ul>');
            angular.forEach(mechanisms.mechanisms, function (mechanism) {
                successMessage.push('<li>' + mechanism.mechanism + '</li>');
            });
            successMessage.push('</ul>');
        }
        toastr.success(successMessage.join(''));
        if (self.hasTableDetails()) {
            self.showData = false;
            self.getTableData();
            self.deSelect();
        }
    });

    $scope.$on('APP.submit.error', function (event, message) {
        toastr.error(message);
        if (self.hasTableDetails()) {
            self.showData = false;
            self.getTableData();
            self.deSelect();
        }
    });

    $scope.$watch(function () {
        return periodService.period;
    }, function (newVal, oldVal) {
        if (newVal !== oldVal) {
            $scope.details.period = newVal.iso;
            mechanismsService.period = $scope.details.period;
        }

        //TODO: See if we can resolve this a bit more clever (It's duplicate with other stuff)
        $scope.details.currentSelection = [];
        self.updateViewButton();
    });

    $scope.$watch(function () {
       return mechanismsService.period;
    }, function (newVal, oldVal) {
        if (newVal !== oldVal) {
            if (self.hasTableDetails()) {
                self.showData = false;
                self.getTableData();
            }
        }
    });

    $scope.$watch(function () {
        if (currentUser.organisationUnits)
            return currentUser.organisationUnits[0].id;
    }, function (newVal, oldVal) {
        if (newVal !== oldVal) {
            $scope.details.orgUnit = newVal;
        }
    });

    $scope.$watch(function () {
        return organisationunitsService.currentOrganisationUnit;
    }, function (newVal, oldVal) {
        if (newVal === oldVal) { return; }

        mechanismsService.organisationUnit = organisationunitsService.currentOrganisationUnit.id;
        $scope.details.orgUnit = mechanismsService.organisationUnit;

        if (self.hasTableDetails()) {
            self.showData = false;
            self.getTableData();
        }
    });
}
appController.$inject = ['periodService', '$scope', 'currentUser', 'mechanismsService', 'approvalLevelsService', '$q', 'toastr', 'AppManifest', 'systemSettings', '$translate', 'd2Api', 'organisationunitsService'];

function tableViewController(mechanismsService, $scope) {
    this.approvalTableConfig = {
        columns: [
            { name: 'mechanism', sortable: true, searchable: true },
            { name: 'country', sortable: true, searchable: true },
            { name: 'agency', sortable: true, searchable: true },
            { name: 'partner', sortable: true, searchable: true },
            { name: 'status', sortable: true, searchable: true },
            { name: 'actions', sortable: true, searchable: true }
        ],
        select: true,
        headerInputClass: 'form-control'
    };

    this.approvalTableDataSource = [];

    //TODO: Perhaps take setActive out of this method as it's called a lot of times this way
    this.hasItems = function (appCtrl, tabName) {
        appCtrl.setActive(tabName, ((!!this.approvalTableData.length) && appCtrl.tabs[tabName] && appCtrl.tabs[tabName].access));

        return !!this.approvalTableData.length;
    };

    this.actionsToFilterOn = [];
    this.filterData = function (data) {
        var result = [];

        _.each(this.actionsToFilterOn, function (filter) {
            result = result.concat(_.filter(data, filter));
        });

        return _.uniq(result);
    };
}
tableViewController.$inject = ['mechanismsService', '$scope'];

function acceptTableViewController($scope, $controller) {
    $.extend(this, $controller('tableViewController', { $scope: $scope }));

    var filterBelowUserLevel = (function (item) {
        if ($scope.approvalLevel && item.level > $scope.approvalLevel.level && item.mayUnapprove === true) {
            return true;
        }
        return false;
    }).bind(this);

    this.actionsToFilterOn = [{ mayAccept: true }, filterBelowUserLevel];
    this.approvalTableData = this.filterData(this.approvalTableDataSource);

    $scope.$on('MECHANISMS.updated', (function (event, mechanisms) {
        this.approvalTableData = this.filterData(mechanisms);
        this.hasActionItems = !!_.filter(this.approvalTableData, { mayAccept: true, level: ($scope.approvalLevel.level - 1) }).length;
    }).bind(this));
}
acceptTableViewController.$inject = ['$scope', '$controller'];

function acceptedTableViewController($scope, $controller) {
    $.extend(this, $controller('tableViewController', { $scope: $scope }));

    this.actionsToFilterOn = [{ mayApprove: true }, { mayUnaccept: true }];
    this.approvalTableData = this.filterData(this.approvalTableDataSource);

    $scope.$on('MECHANISMS.updated', (function (event, mechanisms) {
        this.approvalTableData = this.filterData(mechanisms);
        this.hasActionItems = !!_.filter(this.approvalTableData, { mayApprove: true, level: $scope.approvalLevel.level }).length;
    }).bind(this));
}
acceptedTableViewController.$inject = ['$scope', '$controller'];

function submittedTableViewController($scope, $controller) {
    $.extend(this, $controller('tableViewController', { $scope: $scope }));

    var filterOnLevel = (function (item) {
        if ($scope.approvalLevel && item.level === $scope.approvalLevel.level && item.mayUnapprove === true) {
            return true;
        }
        return false;
    }).bind(this);

    this.actionsToFilterOn = [filterOnLevel];
    this.approvalTableData = this.filterData(this.approvalTableDataSource);

    $scope.$on('MECHANISMS.updated', (function (event, mechanisms) {
        this.approvalTableData = this.filterData(mechanisms);
    }).bind(this));
}
submittedTableViewController.$inject = ['$scope', '$controller'];

function viewTableViewController($scope, $controller) {
    $.extend(this, $controller('tableViewController', { $scope: $scope }));

    //The filter always returns true.
    this.filterData = function (data) {
        return _.filter(data, function () {
            return true;
        }, this);
    };
    this.approvalTableData = this.filterData();

    $scope.$on('MECHANISMS.updated', (function (event, mechanisms) {
        this.approvalTableData = this.filterData(mechanisms);
    }).bind(this));
}
viewTableViewController.$inject = ['$scope', '$controller'];

angular.module('PEPFAR.approvals', ['d2', 'd2-translate', 'ui.select', 'ui.bootstrap.tabs', 'd2-typeahead', 'ui.bootstrap.typeahead', 'ui.bootstrap.progressbar', 'd2Menu']);
angular.module('PEPFAR.approvals').controller('appController', appController);
angular.module('PEPFAR.approvals').controller('tableViewController', tableViewController);
angular.module('PEPFAR.approvals').controller('acceptTableViewController', acceptTableViewController);
angular.module('PEPFAR.approvals').controller('acceptedTableViewController', acceptedTableViewController);
angular.module('PEPFAR.approvals').controller('submittedTableViewController', submittedTableViewController);
angular.module('PEPFAR.approvals').controller('viewTableViewController', viewTableViewController);

angular.module('PEPFAR.approvals').config(['uiSelectConfig', function (uiSelectConfig) {
    uiSelectConfig.theme = 'bootstrap';
}]);

function dataViewController($scope, approvalsService, $translate) {
    var self = this;

    this.filteredDataSets = [];
    this.details = $scope.details;
    this.getMechanismsByIds = function (ids) {
        var ids = _(ids);
        return _.filter(this.details.currentSelection, function (mechanism) {
            return ids.contains(mechanism.id);
        });
    };

    this.isLocked = false;

    this.getActionTextFor = function(type) {
        var translations;

        function ucFirst(value) {
            return value.replace(/^./, function (value) { return value.toUpperCase(); });
        }

        if (this.details.actions && this.details.actions[type]) {
            return $translate.instant(ucFirst(type) + ' {{count}} mechanism(s)', { count: this.details.actions[type].length });
        }
    }

    this.getPeriod = function () {
        return this.details.period;
    };

    this.getDataSetIds = function () {
        if (angular.isArray(this.details.dataSets)) {
            return _.pluck(this.details.dataSets, 'id');
        }
        return [];
    };

    this.getApprovalLevelId = function () {
        if (this.details.approvalLevel) {
            return this.details.approvalLevel.id;
        }
    };

    this.getParamsForMechanism = function () {
        var params = {};

        if (angular.isString(this.getPeriod()) && this.getPeriod().length > 0) {
            params.pe = this.getPeriod();
        }

        if (angular.isArray(this.getDataSetIds()) && this.getDataSetIds().length > 0) {
            params.ds = this.getDataSetIds();
        }

        return params;
    };

    this.isParamsComplete = function () {
        var params = this.getParamsForMechanism();

        if (angular.isObject(params) &&
            angular.isString(params.pe) && params.pe.length > 0 &&
            angular.isArray(params.ds) && params.ds.length > 0) {
            return true;
        }
        return false;
    };

    function getActionCallBackFor(actionName, mechanisms) {
        return function () {
            self.isLocked = false;
            $scope.$emit('APP.submit.success', { action: actionName, mechanisms: mechanisms } );
        }
    }

    function actionErrorCallBack(message) {
        var resultMessage;

        self.isLocked = false;

        if (!/<[a-z][\s\S]*>/.test(message.data) && angular.isString(message.data)) {
            resultMessage = message.data;
        } else {
            resultMessage = (message.status ? message.status + ': ' : '') + message.statusText;
        }

        $scope.$emit('APP.submit.error', $translate.instant(resultMessage));
    }

    function prepareApprovalServiceParams(params, mechanisms) {
        var approvalParams = {};

        approvalParams.approvals = _.map(mechanisms, function (mechanism) {
            return {
                aoc: mechanism.catComboId,
                ou: mechanism.organisationUnit
            };
        });
        approvalParams.pe = [ params.pe ];
        approvalParams.ds = params.ds;
        approvalParams.ou = $scope.details.orgUnit;

        return approvalParams;
    }

    this.submit = function (ids) {
        var params = this.getParamsForMechanism();
        var mechanisms = this.getMechanismsByIds(ids);
        var approvalParams;

        this.isLocked = true;

        if (this.isParamsComplete()) {
            approvalParams= prepareApprovalServiceParams(params, mechanisms);

            if (approvalParams.approvals.length > 0) {
                approvalsService.approve(approvalParams).then(getActionCallBackFor('approve', mechanisms), actionErrorCallBack);
            }
        }
    };

    this.accept = function (ids) {
        var params = this.getParamsForMechanism();
        var mechanisms = this.getMechanismsByIds(ids);
        var approvalParams;

        this.isLocked = true;

        if (this.isParamsComplete()) {
            approvalParams= prepareApprovalServiceParams(params, mechanisms);

            if (approvalParams.approvals.length > 0) {
                approvalsService.accept(approvalParams).then(getActionCallBackFor('accept', mechanisms), actionErrorCallBack);
            }
        }
    };

    this.unapprove = function (ids) {
        var params = this.getParamsForMechanism();
        var mechanisms = this.getMechanismsByIds(ids);
        var approvalParams;

        this.isLocked = true;

        if (this.isParamsComplete()) {
            approvalParams= prepareApprovalServiceParams(params, mechanisms);

            if (approvalParams.approvals.length > 0) {
                approvalsService.unapprove(approvalParams).then(getActionCallBackFor('unapprove', mechanisms), actionErrorCallBack);
            }
        }
    };

    this.unaccept = function (ids) {
        var params = this.getParamsForMechanism();
        var mechanisms = this.getMechanismsByIds(ids);
        var approvalParams;

        this.isLocked = true;

        if (this.isParamsComplete()) {
            approvalParams= prepareApprovalServiceParams(params, mechanisms);

            if (approvalParams.categoryOptionCombos.length > 0) {
                approvalsService.unaccept(approvalParams).then(getActionCallBackFor('unaccept', mechanisms), actionErrorCallBack);
            }
        }
    };
}
dataViewController.$inject = ['$scope', 'approvalsService', '$translate'];

angular.module('PEPFAR.approvals').controller('dataViewController', dataViewController);

function approvalLevelsService($q, d2Api) {
    var promise;
    var orgUnitLevels, approvalLevels;
    this.get = function () {
        return promise;
    };

    d2Api.addEndPoint('organisationUnitLevels');
    d2Api.addEndPoint('dataApprovalLevels');

    orgUnitLevels = d2Api.organisationUnitLevels.getList({
        fields: 'level,displayName',
        paging: false
    });

    approvalLevels = d2Api.dataApprovalLevels.getList({
        fields: 'id,name,displayName,orgUnitLevel,level,categoryOptionGroupSet[id,name]'
    });

    promise = $q.all([orgUnitLevels, approvalLevels]).then(function (results) {
        var orgUnitLevels = results[0].getDataOnly();
        var approvalLevels = results[1].getDataOnly();
        var orgUnitLevelsByLevel = [];

        angular.forEach(orgUnitLevels, function (orgUnitLevel) {
            orgUnitLevelsByLevel[orgUnitLevel.level] = orgUnitLevel.displayName;
        }, this);

        angular.forEach(approvalLevels, function (approvalLevel) {
            if (approvalLevel.categoryOptionGroupSet) {
                approvalLevel.levelName = approvalLevel.categoryOptionGroupSet.name;
            } else {
                approvalLevel.levelName = orgUnitLevelsByLevel[approvalLevel.orgUnitLevel];
            }
        }, this);

        approvalLevels.getCategoryOptionGroupSetIdsForLevels = function () {
            return _.map(_.filter(approvalLevels,'categoryOptionGroupSet'), function (level) {
                if (level.categoryOptionGroupSet) {
                    return {
                        level: level.level,
                        cogsId: level.categoryOptionGroupSet.id
                    };
                }
            });
        }
        return approvalLevels;
    });
}
approvalLevelsService.$inject = ['$q', 'd2Api'];

angular.module('PEPFAR.approvals').service('approvalLevelsService', approvalLevelsService);

function approvalsService($q, d2Api) {

    //TODO rework this to not by default return true
    function checkApprovalData(approvalData) {
        if (!angular.isObject(approvalData)) {
            return 'The parameters for approvals are missing';
        }

        if (!angular.isArray(approvalData.pe) || approvalData.pe.length === 0) {
            return 'Period parameter (pe) is missing or empty';
        }

        if (!angular.isArray(approvalData.ds) || approvalData.ds.length === 0) {
            return 'Dataset id parameter (ds) is missing or empty';
        }

        if (!angular.isArray(approvalData.approvals) || approvalData.approvals.length === 0) {
            return 'Category option combo parameter is missing or empty';
        }

        if (!angular.isString(approvalData.ou) || approvalData.ou.length === 0) {
            return 'Organisation unit (ou) is missing or empty';
        }

        return true;
    }

    this.approve = function (approvalData) {
        var approvalStatus = checkApprovalData(approvalData);

        if (approvalStatus === true) {
            // First parameter is undefined because we do not post a body but
            // the data is in the query params in the second parameter.
            return d2Api.getEndPoint('dataApprovals/approvals').post(approvalData);
        }
        return $q.reject({statusText: approvalStatus});
    };

    this.unapprove = function (approvalData) {
        var approvalStatus = checkApprovalData(approvalData);

        if (approvalStatus === true) {
            return d2Api.getEndPoint('dataApprovals/unapprovals').post(approvalData);
        }
        return $q.reject({statusText: approvalStatus});
    }

    this.accept = function (approvalData) {
        var approvalStatus = checkApprovalData(approvalData);

        if (approvalStatus === true) {
            return d2Api.getEndPoint('dataAcceptances/acceptances').post(approvalData);
        }
        return $q.reject({statusText: approvalStatus});
    }

    this.unaccept = function (approvalData) {
        var approvalStatus = checkApprovalData(approvalData);

        if (approvalStatus === true) {
            return d2Api.getEndPoint('dataAcceptances/unacceptances').post(approvalData);
        }
        return $q.reject({statusText: approvalStatus});
    }

    d2Api.addEndPoint('dataApprovals/approvals');
    d2Api.addEndPoint('dataApprovals/unapprovals');
    d2Api.addEndPoint('dataAcceptances/acceptances');
    d2Api.addEndPoint('dataAcceptances/unacceptances');
}
approvalsService.$inject = ['$q', 'd2Api'];

angular.module('PEPFAR.approvals').service('approvalsService', approvalsService);

function dataSetGroupService(d2Api, $q, periodService) {
    var service = this;
    var dataSetGroups = {};
    var dataSetGroupNames = [];

    this.getGroups = function () {
        return dataSetGroups;
    };

    this.filterDataSetsForUser = function (resultDataSetGroups) {
        var dataSetGroupsPromises = [];

        _.forEach(resultDataSetGroups, function (dataSetGroup) {
            var filteredGroup = {};

            var filters;

            filteredGroup.name = dataSetGroup.name;
            filteredGroup.dataSets = [];

            filters = _.map(dataSetGroup.dataSets, function (dataSetId) {
                return 'id:eq:' + dataSetId;
            });

            dataSetGroupsPromises.push(d2Api.dataSets.getList({
                fields: 'name,shortName,id,periodType,categoryCombo[id,name,categories[id]]',
                filter: filters,
                paging: 'false'
            }).then(function (dataSets) {
                filteredGroup.dataSets = dataSets.getDataOnly();

                var categoryComboIds = {};

                _.each(filteredGroup.dataSets, function (dataSet) {
                    if (dataSet.categoryCombo) {
                        if (categoryComboIds[dataSet.categoryCombo.id]) {
                            categoryComboIds[dataSet.categoryCombo.id].push(dataSet);
                        } else {
                            categoryComboIds[dataSet.categoryCombo.id] = [dataSet];
                        }
                    }
                });

                    _.each(categoryComboIds, function (dataSets, catCombo) {
                        d2Api.categoryCombos.get(catCombo,
                            {fields: 'id,categoryOptionCombos[id,name]'}).then(function (categoryCombo) {
                                _.each(dataSets, function (dataSet) {
                                    dataSet.categoryCombo.categoryOptionCombos = categoryCombo.categoryOptionCombos;
                                });
                            });
                    });


                return filteredGroup;
            }));
        });

        $q.all(dataSetGroupsPromises).then(function (datasetGroups) {
            var initialDataSets;

            _.forEach(datasetGroups, function (filteredGroup) {
                if (filteredGroup.dataSets.length > 0) {
                    dataSetGroups[filteredGroup.name] = filteredGroup;
                }

                dataSetGroupNames = _.map(dataSetGroups, function (dataSetGroup, key) {
                    return key;
                }).sort();
            });

            //TODO: this code is a bit confusing?
            initialDataSets = dataSetGroupFactory()(dataSetGroups[dataSetGroupNames[0]].dataSets);
            periodService.filterPeriodTypes(initialDataSets.getPeriodTypes());
        });
    };

    this.getDataSetGroupNames = function () {
        return dataSetGroupNames;
    };

    this.getDataSetsForGroup = function (dataSetGroupName) {
        if (dataSetGroups[dataSetGroupName]) {
            return dataSetGroups[dataSetGroupName].dataSets;
        }
    };

    // Configure the api endpoints we use
    d2Api.addEndPoint('systemSettings');
    d2Api.addEndPoint('dataSets');

    //Add combo endpoint for MER Hack
    d2Api.addEndPoint('categoryCombos');

    // Load the dataSetGroups that are available from system settings
    d2Api.systemSettings.get('keyApprovalDataSetGroups').then(function (resultDataSetGroups) {
        service.filterDataSetsForUser(resultDataSetGroups);
    });
}
dataSetGroupService.$inject = ['d2Api', '$q', 'periodService'];

function dataSetGroupFactory() {
    return function (dataSets) {
        return {
            get: function () {
                return dataSets;
            },
            getIds: function () {
                return _.pluck(dataSets, 'id');
            },
            getPeriodTypes: function () {
                return _.uniq(_.pluck(dataSets, 'periodType'));
            },
            getCategoryIds: function () {
                var categoriesFromCategoryCombos;

                categoriesFromCategoryCombos = _.pluck(_.pluck(dataSets, 'categoryCombo'), 'categories');
                categoriesFromCategoryCombos = _.flatten(categoriesFromCategoryCombos);
                categoriesFromCategoryCombos = _.pluck(categoriesFromCategoryCombos, 'id');

                return _.uniq(categoriesFromCategoryCombos);
            }
        };
    };
}

angular.module('PEPFAR.approvals').service('dataSetGroupService', dataSetGroupService);
angular.module('PEPFAR.approvals').factory('dataSetGroupFactory', dataSetGroupFactory);

function dataSetGroupSelectorDirective(dataSetGroupService, dataSetGroupFactory) {
    return {
        restrict: 'E',
        replace: true,
        scope: {},
        templateUrl: 'datasets/datasetgroupselector.html',
        link: function (scope) {
            scope.dataset = {
                groups: undefined,
                selectedDataSetGroup: undefined
            };

            function updateDataSetGroups(datasetGroups) {
                if (angular.isArray(datasetGroups)) {
                    scope.dataset.groups = datasetGroups;
                    scope.dataset.selectedDataSetGroup = scope.dataset.groups[0];
                }
            }

            scope.$watch(function () {
                return dataSetGroupService.getDataSetGroupNames();
            }, function (newVal, oldVal) {
                if (newVal !== oldVal) {
                    updateDataSetGroups(newVal);
                }
            });

            scope.$watch(function () {
                return scope.dataset.selectedDataSetGroup;
            }, function (newVal, oldVal) {
                if (newVal !== oldVal) {
                    scope.$emit(
                        'DATASETGROUP.changed',
                        dataSetGroupFactory(dataSetGroupService.getDataSetsForGroup(scope.dataset.selectedDataSetGroup))
                    );
                }
            });

            scope.onChange = function ($item) {
                scope.dataset.selectedDataSetGroup = $item;
            };
        }
    }
}
dataSetGroupSelectorDirective.$inject = ['dataSetGroupService', 'dataSetGroupFactory'];

angular.module('PEPFAR.approvals').directive('datasetGroupSelector', dataSetGroupSelectorDirective);

function datasetViewDirective(AppManifest, $translate) {
    var dataSetReportWrapSelector = '.dataset-report-wrap';

    function loadDataSetReport(details, ds, element, scope) {
        var dataSetReportUrl = AppManifest.activities.dhis.href + '/dhis-web-reporting/generateDataSetReport.action';
        var params = {
            ds: ds.id,
            pe: details.period,
            ou: details.orgUnit
        };

        //Dimensions should be based on the mechanisms that are assigned
        //The category should be based on the result of the selection that is done
        //Leave off the dimension if the category is `default`
        //If the dataset has a category(or multiple, in this case one) get the currentSelection items that have that category
        //If the dataset has the category default don't add the dimension
        var datasetCOCNames = _.pluck(ds.categoryCombo.categoryOptionCombos, 'name');
        var datasetCOCIds;
        var hasDefaultCOC = _.contains(datasetCOCNames, '(default)');

        var COsForReport;
        if (!hasDefaultCOC) {
            datasetCOCIds = _.pluck(ds.categoryCombo.categoryOptionCombos, 'id');
            //Filter out the ones that have default as COG
            COsForReport = _.filter(details.currentSelection, function (mechanism) {
                if (_.contains(datasetCOCIds, mechanism.catComboId)) {
                    return true;
                }
                return false;
            });
            // TODO: This picks the fist category and assumes that all the other COs have the same category
            // which might not be true
            params.dimension = COsForReport[0].category + ':' + _.pluck(COsForReport, 'id').join(';');
        }

        var urlParams = _.map(params,function (value, key) {
            return [key, value].join('=');
        }).join('&');

        var reportUrl = [dataSetReportUrl, urlParams].join('?');

        jQuery.get(reportUrl).success(function (data) {
            scope.$apply(function () {
                scope.details.loaded += 1;
            });
            var reportElement = jQuery('<div class="dataset-view"></div>').append(data);

            var h3Elements = reportElement.find('h3');
            var toRemoveElements = [];

            h3Elements.first().html(ds.name)
                .attr('id', ds.id);

            if (h3Elements.length > 1) {
                h3Elements.each(function (index, element) {
                    if (index > 0) {
                        toRemoveElements.push(element);
                    }
                });
            }

            _.each(toRemoveElements, function (element) {
                jQuery(element).remove();
            });

            //Remove the hidden input fields
            reportElement.find('input[type="hidden"]').remove();

            //Remove the userinfo field
            reportElement.find('div#userInfo').remove();

            //Remove empty p element
            //reportElement.find('div.cde p:last-child').remove();

            //Remove the share form
            reportElement.find('div#shareForm').remove();

            //Remove the comment boxes for EA forms
            reportElement.find('.ea-comment').parentsUntil('div').remove();

            //Remove the background and color inline styles and add a class to the items that had a background
            //reportElement.find('[style*="background"]').css('background', '').addClass('dataset-view-highlight');
            //reportElement.find('[style*="color"]').css('color', '');

            scope.reportView[ds.id].content = reportElement;
            scope.updateCurrentViewIfNeeded(ds);
        });
    }

    //TODO: Take this into it's own directive (could be usable for reuse
    function addBackToTop(translation) {
        var backToTop = jQuery('<div class="back-to-top"><i class="fa fa-angle-double-up"></i><span>&nbsp;' + translation + '</span></div>');

        backToTop.on('click', function () {
            window.scrollTo(0, 0);
        });

        jQuery('.view-wrap').append(backToTop);
    }


    return {
        restrict: 'E',
        replace: true,
        templateUrl: 'datasets/datasetsview.html',
        scope: {},
        link: function (scope, element) {
            scope.reportView = {
                actions: {
                    approve: { count: 0 },
                    unapprove: { count: 0 },
                    accept: { count: 0 },
                    unaccept: { count: 0 }
                }
            };

            scope.$on('DATAVIEW.update', function (event, details) {
                scope.details = details;
                scope.checkValues();
            });

            scope.checkValues = function () {
                var details = scope.details;

                if (details.orgUnit &&
                    details.period &&
                    details.dataSets &&
                    details.currentSelection &&
                    details.actions) {

                    scope.loadReports();
                }
            };

            scope.hasUnreadableMechanisms = 0;
            scope.loadReports = function () {
                var details = scope.details;
                scope.details.dataSetsFilteredByMechanisms = _.filter(details.dataSets, function (dataSet) {
                    var result = false;
                    var categoryOptionComboIds;

                    if (!dataSet.categoryCombo || !angular.isArray(dataSet.categoryCombo.categoryOptionCombos)) {
                        return false;
                    }

                    categoryOptionComboIds = _.pluck(dataSet.categoryCombo.categoryOptionCombos, 'id');

                    _.each(scope.details.currentSelection, function (mechanism) {
                        if (mechanism.mayReadData === false) {
                            scope.hasUnreadableMechanisms += 1;
                        }

                        if (_.contains(categoryOptionComboIds, mechanism.catComboId)) {
                            result = true;
                        }
                    });
                    return result;
                });

                //Move this out
                jQuery(dataSetReportWrapSelector).html('');

                $translate('Back to top').then(function (translation) {
                    addBackToTop(translation);
                });

                scope.details.loaded = 0;
                scope.reportView.currentDataSet = scope.details.dataSetsFilteredByMechanisms[0];
                scope.details.dataSetsFilteredByMechanisms.forEach(function (item) {
                    loadDataSetReport(scope.details, item, element.find(dataSetReportWrapSelector), scope);
                    scope.reportView[item.id] = {};
                    scope.reportView[item.id].content = angular.element('<div class="report-loading-message"><i class="fa fa-circle-o-notch fa-spin"></i> Loading report: <span class="report-name">' + item.name + '</span></div>');
                });

                //Add the first element
                element.find(dataSetReportWrapSelector).append(scope.reportView[scope.details.dataSetsFilteredByMechanisms[0].id].content);
            };

            scope.onChange = function ($event, $item) {
                try {
                    if (scope.reportView[$item.id].content) {
                        if (element.find(dataSetReportWrapSelector).children().length > 0) {
                            element.find(dataSetReportWrapSelector).children().replaceWith(scope.reportView[$item.id].content);
                        } else {
                            element.find(dataSetReportWrapSelector).append(scope.reportView[$item.id].content);
                        }
                    }
                } catch (e) {
                    console.error(e);
                }
            };

            scope.updateCurrentViewIfNeeded = function (dataSet) {
                if (scope.reportView.currentDataSet &&
                    scope.reportView.currentDataSet.id === dataSet.id) {
                    scope.onChange({}, dataSet);
                }
            };
        }
    };
}
datasetViewDirective.$inject = ['AppManifest', '$translate'];

angular.module('PEPFAR.approvals').directive('datasetView', datasetViewDirective);

function mechanismsService(d2Api, $log, $q, approvalLevelsService) {
    var self = this;
    var AGENCY_LEVEL = 3;
    var PARTNER_LEVEL = 4;

    var period;
    var dataSetIds = [];
    var categories = [];
    var organisationUnit = '';

    var deferred = $q.defer();

    var statuses = {
        'accepted': 'Accepted',
        'submitted': 'Submitted'
    };

    var mechanisms = [];

    var orgUnitCache = {};
    var categoryCache = {};

    Object.defineProperty(this, 'period', {
        set: function (value) {
            if (!angular.isString(value)) {
                $log.error('Mechanism Service: Period should be a string');
                return;
            }
            period = value;
        },
        get: function () {
            return period;
        }
    });

    Object.defineProperty(this, 'dataSetIds', {
        set: function (value) {
            if (!angular.isArray(value)) {
                $log.error('Mechanism Service: DataSets should be a string');
                return;
            }
            dataSetIds = value;
        },
        get: function () {
            return dataSetIds;
        }
    });

    Object.defineProperty(this, 'categories', {
        set: function (value) {
            if (!angular.isArray(value)) {
                $log.error('Mechanism Service: Categories should be an array');
                return;
            }
            categories = value;
        },
        get: function () {
            return categories;
        }
    });

    Object.defineProperty(this, 'organisationUnit', {
        set: function (value) {
            if (!angular.isString(value)) {
                $log.error('Mechanism Service: OrganisationUnit should be a string');
                return;
            }
            organisationUnit = value;
        },
        get: function () {
            return organisationUnit;
        }
    });

    this.getMechanisms = function () {
        function parseData(categories, cogsIdsForLevels) {
            var data;

            var agencyCOGSId = _.find(cogsIdsForLevels, function (cogsIdsForLevel) {
                if (cogsIdsForLevel.level === AGENCY_LEVEL) {
                    return true;
                }
                return false;
            }).cogsId;

            var parterCOGSId = _.find(cogsIdsForLevels, function (cogsIdsForLevel) {
                if (cogsIdsForLevel.level === PARTNER_LEVEL) {
                    return true;
                }
                return false;
            }).cogsId;

            data = _(categories).map(function (category) {
                return _.map(category.categoryOptions, function (categoryOption) {
                    var mechanism = {
                        id: categoryOption.id,
                        mechanism: categoryOption.name,
                        country: getCountryFromCategoryOption(categoryOption),
                        agency: getAgencyFromCategoryOption(categoryOption.categoryOptionGroups || [], agencyCOGSId),
                        partner: getPartnerFromCategoryOption(categoryOption.categoryOptionGroups || [], parterCOGSId),
                        status: '',
                        actions: '',
                        category: category.id,
                        catComboId: categoryOption.categoryOptionCombos[0].id //FIXME: Hacked for pepfar to always be the first
                    };
                    return mechanism;
                });
            }).flatten();

            return data.__wrapped__;
        }

        function getCountryFromCategoryOption(categoryOption) {
            if (categoryOption.organisationUnits[0]) {
                orgUnitCache[categoryOption.organisationUnits[0].id] = categoryOption.organisationUnits[0].name;
            }

            return categoryOption.organisationUnits[0] ? categoryOption.organisationUnits[0].name : ''
        }

        function getPartnerFromCategoryOption(categoryOptionGroups, parterCOGSId) {
            var partner = _.find(categoryOptionGroups, function (categoryOptionGroup) {
                if (categoryOptionGroup.categoryOptionGroupSet &&
                    categoryOptionGroup.categoryOptionGroupSet.id &&
                    categoryOptionGroup.categoryOptionGroupSet.id === parterCOGSId) {
                    return true;
                }
                return false;
            });

            if (partner) {
                return partner.name;
            }
            return '';
        }

        function getAgencyFromCategoryOption(categoryOptionGroups, agencyCOGSId) {
            var agency = _.find(categoryOptionGroups, function (categoryOptionGroup) {
                if (categoryOptionGroup.categoryOptionGroupSet &&
                    categoryOptionGroup.categoryOptionGroupSet.id &&
                    categoryOptionGroup.categoryOptionGroupSet.id === agencyCOGSId) {
                    return true;
                }
                return false;
            });

            if (agency) {
                return agency.name;
            }
            return '';
        }

        function getCategoriesAndReplaceDefaults() {
            var deferred = $q.defer();

            //Load categories from cache
            if (categoryCache[categories.join('_')]) {
                deferred.resolve(categoryCache[categories.join('_')]);
                return deferred.promise;
            }

            self.getData().then(function (data) {
                _.each(data, function (category) {
                    _.each(self.dataSets, function (dataSet) {
                        if (dataSet.categoryCombo.name === 'default' &&
                            dataSet.categoryCombo.categories[0].id === category.id) {
                            _.each(category.categoryOptions, function (mechanism) {
                                if (mechanism.name === 'default') {
                                    mechanism.name = dataSet.name;
                                    mechanism.hasDefaultCategory = true;
                                }
                            });
                        }
                    });
                });
                categoryCache[categories.join('_')] = data;
                deferred.resolve(data);
            }, function () {
                deferred.reject('Error loading category data');
            });

            return deferred.promise;
        }

        return $q.all([getCategoriesAndReplaceDefaults(), approvalLevelsService.get(), this.getStatuses()]).then(function (data) {
            var parsedData = parseData(data[0], data[1].getCategoryOptionGroupSetIdsForLevels());

            self.filterMechanisms(data[2], parsedData, data[1]);

            return mechanisms;
        }, function (err) {
            $log.error('Mechanism Service: Unable to parse the mechanisms');
        });
    };

    this.filterMechanisms = function (mechanismsStatuses, parsedData, approvalLevels) {
        mechanisms = [];
        _.each(mechanismsStatuses, function (mechanismStatus) {
            var actions = [];
            var status = [];
            var approvalLevel;
            var mechanism =  angular.copy(_.find(parsedData, { catComboId: mechanismStatus.id }));

            if (mechanismStatus.level && mechanismStatus.level.id) {
                approvalLevel = _.find(approvalLevels, { id: mechanismStatus.level.id });
            }

            if (!mechanism) { return; }

            if (mechanismStatus.permissions.mayApprove === true) {
                mechanism.mayApprove = true;
                actions.push('Submit');
            }
            if (mechanismStatus.permissions.mayUnapprove === true) {
                mechanism.mayUnapprove = true;
                actions.push('Unsubmit');
            }
            if (mechanismStatus.permissions.mayUnaccept === true) {
                mechanism.mayUnaccept = true;
                actions.push('Unaccept');
            }
            if (mechanismStatus.permissions.mayAccept === true) {
                mechanism.mayAccept = true;
                actions.push('Accept');
            }

            if (mechanismStatus.permissions.mayReadData === true) {
                mechanism.mayReadData = true;
            } else {
                mechanism.mayReadData = false;
            }

            if (approvalLevel) {
                if (mechanismStatus.accepted === true) {
                    status.push('Accepted');
                } else {
                    status.push('Submitted');
                }
                status.push(approvalLevel.levelName);
            } else {
                status.push('Pending');
            }


            mechanism.status = status.join(' by ');
            mechanism.actions = actions.join(', ');
            mechanism.organisationUnit = mechanismStatus.ou;

            if (mechanism.country === '') {
                if (orgUnitCache[mechanismStatus.ou]) {
                    mechanism.country = orgUnitCache[mechanismStatus.ou];
                }
            }

            mechanism.level = mechanismStatus.level && parseInt(mechanismStatus.level.level, 10) || undefined ;
            mechanisms.push(mechanism);
        });
    };

    this.getData = function () {
        var deferred = $q.defer();
        var params = {
            paging: false,
            filter: _.map(categories, function (category) {
                return 'id:eq:' + category;
            }),
            fields: 'id,name,categoryOptions[id,name,organisationUnits[id,name],categoryOptionCombos[id,name],categoryOptionGroups[id,name,categoryOptionGroupSet[id]]'
        };

        if (this.areParamsCorrect(params)) {
            d2Api.getEndPoint('categories').getList(params).then(function (data) {
                deferred.resolve(data.getDataOnly());
            }, function () {
                deferred.reject('Request for categories failed');
            });
        } else {
            deferred.reject('Not all required params are set');
        }

        return deferred.promise;
    };

    this.getStatuses = function () {
        return d2Api.getEndPoint('dataApprovals/categoryOptionCombos').getList({
            pe: period,
            ds: dataSetIds,
            ou: organisationUnit
        }).then(function (data) {
            return data.getDataOnly();
        });
    };

    this.areParamsCorrect = function (params) {
        if (params.filter.length <= 0) {
            $log.error('Mechanism Service: Categories should set when trying to request mechanisms');
            return false;
        }
        return true;
    };

    d2Api.addEndPoint('categories');
    d2Api.addEndPoint('dataApprovals/categoryOptionCombos');
}
mechanismsService.$inject = ['d2Api', '$log', '$q', 'approvalLevelsService'];

angular.module('PEPFAR.approvals').service('mechanismsService', mechanismsService);

function organisationunitSelectorDirective(organisationunitsService) {
    return {
        restrict: 'E',
        replace: true,
        scope: true,
        templateUrl: 'organisationunits/organisationunitselector.html',
        link: function (scope) {
            scope.organisationUnit = {
                selected: undefined,
                organisationUnits: [],
                currentOrganisationUnit: {}
            };

            scope.$watch(function () {
                return organisationunitsService.currentOrganisationUnit;
            }, function (newVal, oldVal) {
                var levelToGet;

                if (newVal === oldVal) { return; }

                if (organisationunitsService.currentOrganisationUnit && organisationunitsService.currentOrganisationUnit.level) {
                    levelToGet = organisationunitsService.currentOrganisationUnit.level + 1;

                    //TODO: PEPFAR Hack to only display this option for global users
                    if (organisationunitsService.currentOrganisationUnit.level != 1) { return; }

                    organisationunitsService.requestOrganisationUnitsForLevel(organisationunitsService.currentOrganisationUnit.id, levelToGet).then(function (dataList) {
                        var thisOrgUnit = {
                            id: organisationunitsService.currentOrganisationUnit.id,
                            name: organisationunitsService.currentOrganisationUnit.name
                        };
                        dataList = _.sortBy(dataList, 'name');
                        scope.organisationUnit.organisationUnits = [thisOrgUnit].concat(dataList);
                        scope.organisationUnit.selected = scope.organisationUnit.organisationUnits[0];
                    });
                }
            }, true);

            scope.changeOrganisationUnit = function ($item) {
                organisationunitsService.currentOrganisationUnit = $item;
            }
        }
    }
}
organisationunitSelectorDirective.$inject = ['organisationunitsService'];

angular.module('PEPFAR.approvals').directive('organisationunitSelector', organisationunitSelectorDirective);

function organisationunitsService(d2Api) {
    this.currentOrganisationUnit = {};

    this.requestOrganisationUnitsForLevel = function (orgUnitId, orgUnitLevel) {
        return d2Api.organisationUnits.get(orgUnitId, {
            fields: 'id,name',
            level: orgUnitLevel,
            paging: 'false'
        }).then(function (organisationUnitData) {
            return organisationUnitData.organisationUnits;
        });
    };

    d2Api.addEndPoint('organisationUnits');
}
organisationunitsService.$inject = ['d2Api'];

angular.module('PEPFAR.approvals').service('organisationunitsService', organisationunitsService);

/**
 * The following is period code taken from the core to give me an idea
 * of how to implement this.
 *
 * TODO: We should be able to remove this soon.
 */

//var periods = dhis2.period.generator.generateReversedPeriods('Monthly', 0);
//periods = dhis2.period.generator.filterFuturePeriodsExceptCurrent( periods );

//// calendar
//(function() {
//    var dhis2PeriodUrl = '../dhis-web-commons/javascripts/dhis2/dhis2.period.js',
//        defaultCalendarId = 'gregorian',
//        calendarIdMap = {'iso8601': defaultCalendarId},
//        calendarId = calendarIdMap[init.systemInfo.calendar] || init.systemInfo.calendar || defaultCalendarId,
//        calendarIds = ['coptic', 'ethiopian', 'islamic', 'julian', 'nepali', 'thai'],
//        calendarScriptUrl,
//        createGenerator;
//
//    // calendar
//    createGenerator = function() {
//        init.calendar = $.calendars.instance(calendarId);
//        init.periodGenerator = new dhis2.period.PeriodGenerator(init.calendar, init.systemInfo.dateFormat);
//    };
//
//    if (Ext.Array.contains(calendarIds, calendarId)) {
//        calendarScriptUrl = '../dhis-web-commons/javascripts/jQuery/calendars/jquery.calendars.' + calendarId + '.min.js';
//
//        Ext.Loader.injectScriptElement(calendarScriptUrl, function() {
//            Ext.Loader.injectScriptElement(dhis2PeriodUrl, createGenerator);
//        });
//    }
//    else {
//        Ext.Loader.injectScriptElement(dhis2PeriodUrl, createGenerator);
//    }
//}());

//var periods = dhis2.period.generator.generateReversedPeriods('Monthly', 0);
//periods = dhis2.period.generator.filterFuturePeriodsExceptCurrent( periods );

//console.log(periods);

//FIXME: the service is not consistent with getters and setters
function periodService(d2Api) {
    var service = this;

    var currentPeriodType;
    var currentPeriod;
    var generatedPeriods;
    var calendarType;
    var dateFormat = 'yyyy-mm-dd';
    var periodTypes = [
        "Daily",
        "Weekly",
        "Monthly",
        "BiMonthly",
        "Quarterly",
        "SixMonthly",
        "SixMonthlyApril",
        "Yearly",
        "FinancialApril",
        "FinancialJuly",
        "FinancialOct"
    ];
    var periodBaseList = periodTypes;

    var calendarTypes = [
        'coptic',
        'ethiopian',
        'islamic',
        'julian',
        'nepali',
        'thai'
    ];

    Object.defineProperties(this, {
        period: {
            get: function () { return currentPeriod; },
            set: function (period) { currentPeriod = period; }
        },
        periodType: {
            get: function () { return currentPeriodType; }
        }
    });

    this.prepareCalendar = function () {
        var calendar = $.calendars.instance(service.getCalendarType());
        dhis2.period.generator = new dhis2.period.PeriodGenerator(calendar, this.getDateFormat());
    }

    this.getDateFormat = function () {
        return dateFormat;
    };

    this.getPeriodTypes = function () {
        return periodTypes;
    };

    this.getCalendarTypes = function () {
        return calendarTypes;
    };

    this.getCalendarType = function () {
        return calendarType;
    };

    this.getPastPeriodsRecentFirst = function () {
        return generatedPeriods;
    };

    this.setPeriodType = function (periodType) {
        var periods;
        if (_(periodTypes).contains(periodType)) {
            currentPeriodType = periodType;
            periods = dhis2.period.generator.generateReversedPeriods(currentPeriodType, 0);
            generatedPeriods =  dhis2.period.generator.filterFuturePeriodsExceptCurrent(periods);
        }
    };

    this.loadCalendarScript = function (calendarType) {
        jQuery.getScript('../dhis-web-commons/javascripts/jQuery/calendars/jquery.calendars.' + calendarType + '.min.js',
            function () {
                service.prepareCalendar();
            }).error(function () {
                throw new Error('Unable to load ' + calendarType + ' calendar');
            });

    };

    this.getPeriodTypesForDataSet = function (dataSetPeriodTypes) {
        var firstPeriodIndex = _(periodBaseList).findLastIndex(function (periodType) {
            return _(dataSetPeriodTypes).contains(periodType);
        });
        return _.rest(periodBaseList, firstPeriodIndex);
    };

    this.filterPeriodTypes = function (dataSetPeriodTypes) {
        periodTypes = this.getPeriodTypesForDataSet(dataSetPeriodTypes);
        return periodTypes;
    };

    d2Api.addEndPoint('system/info', true);
    d2Api.getEndPoint('system/info').get().then(function (info) {
        dateFormat = info.dateFormat;

        if (info.calendar === 'iso8601') {
            calendarType = 'gregorian';
            service.prepareCalendar();
        } else {
            calendarType = info.calendar;

            if (_(calendarTypes).contains(calendarType)) {
                service.loadCalendarScript(calendarType);
            }
        }
    });
}
periodService.$inject = ['d2Api'];

angular.module('PEPFAR.approvals').service('periodService', periodService);

function periodSelectorDirective(periodService) {
    return {
        restrict: 'E',
        replace: true,
        scope: true,
        templateUrl: 'period/periodselector.html',
        link: function (scope, element) {
            scope.period = {
                selectedPeriodType: undefined,
                selectedPeriod: undefined,
                periodTypes: periodService.getPeriodTypes(),
                periodsRecentFirst: periodService.getPastPeriodsRecentFirst()
            };

            scope.$watch(function () {
                return periodService.getPeriodTypes();
            }, function (newVal, oldVal) {
                 if (newVal !== oldVal) {
                     scope.period.periodTypes = periodService.getPeriodTypes();
                     scope.period.selectedPeriodType = scope.period.periodTypes[0];
                     scope.changedPeriodType(scope.period.selectedPeriodType);
                 }
            });

            scope.changedPeriodType = function ($item, $model) {
                periodService.setPeriodType($item);
                scope.period.periodsRecentFirst = periodService.getPastPeriodsRecentFirst();

                //Always select the first period when a new type is picked
                scope.period.selectedPeriod = scope.period.periodsRecentFirst[0];
                scope.changePeriod(scope.period.selectedPeriod);
            };

            scope.changePeriod = function ($item) {
                if ($item === undefined) { return; }

                periodService.period = $item;
            };
        }
    }
}
periodSelectorDirective.$inject = ['periodService'];

angular.module('PEPFAR.approvals').directive('periodSelector', periodSelectorDirective);

angular.module('PEPFAR.approvals').factory('toastr', function () {
    var toastrOptions;

    if (window.toastr) {
        toastrOptions = window.toastr.options;
        toastrOptions.positionClass = "toast-top-right";
        toastrOptions.timeOut = 0;
        toastrOptions.extendedTimeOut = 0;
        toastrOptions.closeButton = true;
        toastrOptions.tapToDismiss = false;

        return window.toastr;
    }
    throw Error('Toastr.js library does not seem to be loaded.');
});